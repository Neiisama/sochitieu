# Sổ Chi Tiêu: build APK bằng GitHub Actions

1. Tạo repo mới trên github.com (để Private cũng được).
2. Upload TOÀN BỘ nội dung thư mục này lên repo (kể cả thư mục ẩn `.github`).
   Cách dễ: cài GitHub Desktop, hoặc dùng git:
       git init && git add . && git commit -m "init"
       git branch -M main
       git remote add origin <link-repo>
       git push -u origin main
3. Vào tab **Actions** -> workflow **Build APK** -> chờ chạy xong (3-5 phút).
   (Nếu không tự chạy: bấm **Run workflow**.)
4. Mở lần chạy đó, kéo xuống mục **Artifacts**, tải `so-chi-tieu-apk` (file zip chứa app-debug.apk).
5. Chép APK sang điện thoại, bật "Cài đặt từ nguồn không xác định" rồi cài.

Lưu ý:
- Dữ liệu nằm trong app. Gỡ app là mất dữ liệu: hãy Export JSON định kỳ.
- Trong app, nút "Tải xuống" có thể không chạy; dùng "Sao chép" rồi dán vào ghi chú.
- Đổi tên/ID app: sửa `capacitor.config.json`.
- Muốn sửa giao diện: sửa `www/index.html` rồi push lại, APK mới sẽ được build.
